const doc = document

const canvas = doc.querySelector('#canv')
ctx = canvas.getContext('2d')

let system = {
    currentTool: null,
    currentColor: '#000',
    brushSize: 5
}

function getCoordinates(evt) {
    doc.querySelector('#x-coord').innerText = evt.offsetX
    doc.querySelector('#y-coord').innerText = evt.offsetY
}

function renderSystem(elem, act) {
    system[elem] = act
}

function handleClick(evt) {
    if (evt.target.classList.contains('tool-button')) {
        renderSystem('currentTool', evt.target.dataset.name)
    }
}

function handleInput(evt) {
    if (evt.target.id === 'select-size') {
        renderSystem('brushSize', evt.target.value)
    }
    if (evt.target.id === 'select-color') {
        renderSystem('currentColor', evt.target.value)
    }
}

function startDraw(evt) {
    if (system.currentTool === 'pencil') {
        pencil(evt)
    }
else if (system.currentTool === 'brush') {
        brush(evt)
    }
else if (system.currentTool === 'spray') {
        spray(evt)
    }
else if (system.currentTool === 'barb') {
        barb(evt)
    }
}

function endDraw() {
    canvas.onmousemove = null
}

//add Tool

function pencil() {
    canvas.onmousemove = function () {
        let x = +doc.querySelector('#x-coord').innerText
        let y = +doc.querySelector('#y-coord').innerText
        ctx.beginPath();
        ctx.fillStyle = system.currentColor
        ctx.fillRect(x, y, system.brushSize, system.brushSize)
    }
}

function brush() {
    canvas.onmousemove = function () {
        let x = +doc.querySelector('#x-coord').innerText
        let y = +doc.querySelector('#y-coord').innerText
        ctx.beginPath();
        ctx.arc(x, y, system.brushSize, 0, Math.PI * 2, false);
        ctx.fill();
        ctx.lineWidth = system.brushSize;
        ctx.strokeStyle = system.currentColor;
    }
}

function spray (){
    canvas.onmousemove = function () {
        let x = +doc.querySelector('#x-coord').innerText
        let y = +doc.querySelector('#y-coord').innerText
        ctx.beginPath();
          ctx.fillStyle = system.currentColor;	
          
          for (var i = 20; i--;) { 
            ctx.rect(x + Math.random() * 20 - 10, 
                         y + Math.random() * 20 - 10, 1, 1);
            ctx.fill();
          }
          
        }
      }

function barb (){
      canvas.onmousemove = function () {
        let x = +doc.querySelector('#x-coord').innerText
        let y = +doc.querySelector('#y-coord').innerText
        ctx.beginPath();
          ctx.strokeStyle = system.currentColor;
          ctx.lineTo(x, y);			
          ctx.lineTo(x + Math.random() * 20 - 10, 
                         y + Math.random() * 20 - 10, 1,1);				
          ctx.stroke();
        }
      }


clearCanvas.onclick = function () {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

canvas.addEventListener('mousemove', getCoordinates)
canvas.addEventListener('mousedown', startDraw)
canvas.addEventListener('mouseup', endDraw)
doc.addEventListener('click', handleClick)
doc.addEventListener('input', handleInput)
